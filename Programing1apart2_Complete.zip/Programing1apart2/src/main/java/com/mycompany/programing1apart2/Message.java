package com.mycompany.programing1apart2;

public class Message {

    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageFlag;

    public Message(String messageID, String recipient, String message) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
        this.numMessagesSent = 0;
        this.messageFlag = "Sent";
    }

    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        if (recipient.matches("^\\+\\d{1,3}\\d{1,10}$") && recipient.length() <= 13) {
            return recipient;
        }
        return null;
    }

    public String createMessageHash() {
        if (messageID.length() < 2 || message.isEmpty()) {
            return null;
        }

        String firstTwoDigits = messageID.substring(0, 2);
        String messageLength = String.valueOf(numMessagesSent);
        String firstWord = message.split(" ")[0];
        String lastWord = message.split(" ")[message.split(" ").length - 1];

        return (firstTwoDigits + ":" + messageLength + ":" + firstWord + lastWord).toUpperCase();
    }

    public String sentMessage() {
        if (!checkMessageID()) {
            return null;
        }
        if (checkRecipientCell() == null) {
            return null;
        }
        if (message.length() > 250) {
            return "Message exceeds 250 characters by " + (message.length() - 250) + " [enter number here]; please reduce the size.";
        }

        messageHash = createMessageHash();
        numMessagesSent++;
        return "Message sent";
    }

    public String printMessages() {
        return "Message ID: " + messageID + ", Hash: " + messageHash + ", Recipient: " + recipient + ", Message: " + message;
    }

    public int returnTotalMessages() {
        return numMessagesSent;
    }

    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public void setMessageHash(String hash) {
        this.messageHash = hash;
    }

    public void setNumMessagesSent(int num) {
        this.numMessagesSent = num;
    }

    public int getNumMessagesSent() {
        return numMessagesSent;
    }

    public String getMessageFlag() {
        return messageFlag;
    }

    public void setMessageFlag(String flag) {
        this.messageFlag = flag;
    }
}
