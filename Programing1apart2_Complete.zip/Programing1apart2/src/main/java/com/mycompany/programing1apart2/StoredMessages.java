package com.mycompany.programing1apart2;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class StoredMessages {

    private List<Message> sentMessages;
    private List<Message> disregardedMessages;
    private List<Message> storedMessages;
    private List<String> messageHashArray;
    private List<String> messageIDArray;
    private String jsonFilePath;

    public StoredMessages() {
        this.sentMessages = new ArrayList<>();
        this.disregardedMessages = new ArrayList<>();
        this.storedMessages = new ArrayList<>();
        this.messageHashArray = new ArrayList<>();
        this.messageIDArray = new ArrayList<>();
        this.jsonFilePath = "messages.json";
    }

    public void addSentMessage(Message msg) {
        sentMessages.add(msg);
        messageHashArray.add(msg.getMessageHash());
        messageIDArray.add(msg.getMessageID());
    }

    public void addDisregardedMessage(Message msg) {
        disregardedMessages.add(msg);
    }

    public void addStoredMessage(Message msg) {
        storedMessages.add(msg);
        messageHashArray.add(msg.getMessageHash());
        messageIDArray.add(msg.getMessageID());
    }

    public List<Message> getSentMessages() {
        return sentMessages;
    }

    public List<Message> getDisregardedMessages() {
        return disregardedMessages;
    }

    public List<Message> getStoredMessages() {
        return storedMessages;
    }

    public List<String> getMessageHashArray() {
        return messageHashArray;
    }

    public List<String> getMessageIDArray() {
        return messageIDArray;
    }

    public void displaySenderAndRecipient() {
        if (storedMessages.isEmpty()) {
            System.out.println("No stored messages found.");
            return;
        }

        System.out.println("\n=== Stored Messages - Sender and Recipient ===");
        for (Message msg : storedMessages) {
            System.out.println("Message ID: " + msg.getMessageID() + " | Recipient: " + msg.getRecipient());
        }
    }

    public String displayLongestMessage() {
        if (storedMessages.isEmpty()) {
            return null;
        }

        Message longestMsg = storedMessages.get(0);
        for (Message msg : storedMessages) {
            if (msg.getMessage().length() > longestMsg.getMessage().length()) {
                longestMsg = msg;
            }
        }

        System.out.println("\n=== Longest Stored Message ===");
        System.out.println(longestMsg.printMessages());
        return longestMsg.getMessage();
    }

    public Message searchMessageByID(String messageID) {
        for (Message msg : storedMessages) {
            if (msg.getMessageID().equals(messageID)) {
                System.out.println("\n=== Search Result ===");
                System.out.println("Message: " + msg.getMessage());
                System.out.println("Recipient: " + msg.getRecipient());
                return msg;
            }
        }
        System.out.println("Message ID not found.");
        return null;
    }

    public List<Message> searchMessagesByRecipient(String recipient) {
        List<Message> results = new ArrayList<>();
        for (Message msg : storedMessages) {
            if (msg.getRecipient().equals(recipient)) {
                results.add(msg);
            }
        }

        if (results.isEmpty()) {
            System.out.println("No messages found for recipient: " + recipient);
        } else {
            System.out.println("\n=== Messages for Recipient: " + recipient + " ===");
            for (Message msg : results) {
                System.out.println(msg.printMessages());
            }
        }

        return results;
    }

    public boolean deleteMessageByHash(String hash) {
        for (int i = 0; i < storedMessages.size(); i++) {
            if (storedMessages.get(i).getMessageHash().equals(hash)) {
                Message deletedMsg = storedMessages.remove(i);
                messageHashArray.remove(hash);
                messageIDArray.remove(deletedMsg.getMessageID());
                System.out.println("Message deleted successfully: " + deletedMsg.getMessage());
                return true;
            }
        }
        System.out.println("Message hash not found.");
        return false;
    }

    public void displayReport() {
        if (sentMessages.isEmpty()) {
            System.out.println("No sent messages to report.");
            return;
        }

        System.out.println("\n=== Sent Messages Report ===");
        System.out.println(String.format("%-15s %-15s %-25s", "Message Hash", "Recipient", "Message"));
        System.out.println("=".repeat(55));

        for (Message msg : sentMessages) {
            System.out.println(String.format("%-15s %-15s %-25s", 
                msg.getMessageHash() != null ? msg.getMessageHash() : "N/A",
                msg.getRecipient(),
                msg.getMessage()));
        }
    }

    public void saveMessagesToJSON() {
        JSONArray jsonArray = new JSONArray();

        for (Message msg : storedMessages) {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("messageID", msg.getMessageID());
            jsonObj.put("recipient", msg.getRecipient());
            jsonObj.put("message", msg.getMessage());
            jsonObj.put("messageHash", msg.getMessageHash());
            jsonObj.put("messageFlag", msg.getMessageFlag());
            jsonArray.add(jsonObj);
        }

        try (FileWriter file = new FileWriter(jsonFilePath)) {
            file.write(jsonArray.toJSONString());
            System.out.println("Messages saved to " + jsonFilePath);
        } catch (IOException e) {
            System.out.println("Error saving messages: " + e.getMessage());
        }
    }

    public void loadMessagesFromJSON() {
        JSONParser parser = new JSONParser();
        storedMessages.clear();
        messageHashArray.clear();
        messageIDArray.clear();

        try (FileReader reader = new FileReader(jsonFilePath)) {
            Object obj = parser.parse(reader);
            JSONArray jsonArray = (JSONArray) obj;

            for (Object msgObj : jsonArray) {
                JSONObject jsonObj = (JSONObject) msgObj;

                String messageID = (String) jsonObj.get("messageID");
                String recipient = (String) jsonObj.get("recipient");
                String messageText = (String) jsonObj.get("message");
                String messageHash = (String) jsonObj.get("messageHash");
                String messageFlag = (String) jsonObj.get("messageFlag");

                Message msg = new Message(messageID, recipient, messageText);
                msg.setMessageHash(messageHash);
                msg.setMessageFlag(messageFlag);

                storedMessages.add(msg);
                messageHashArray.add(messageHash);
                messageIDArray.add(messageID);
            }

            System.out.println("Messages loaded from " + jsonFilePath + ". Total: " + storedMessages.size());
        } catch (IOException e) {
            System.out.println("File not found or error reading: " + e.getMessage());
        } catch (ParseException e) {
            System.out.println("Error parsing JSON: " + e.getMessage());
        }
    }

    public int getTotalStoredMessages() {
        return storedMessages.size();
    }

    public int getTotalSentMessages() {
        return sentMessages.size();
    }

    public int getTotalDisregardedMessages() {
        return disregardedMessages.size();
    }
}
