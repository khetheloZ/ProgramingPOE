package com.mycompany.programing1apart2;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class QuickChat {

    private static Login currentUser = null;
    private static StoredMessages messageStore = new StoredMessages();
    private static Scanner input = new Scanner(System.in);
    private static List<Login> registeredUsers = new ArrayList<>();

    public static void main(String[] args) {
        displayWelcome();

        while (true) {
            if (currentUser == null) {
                displayMainMenu();
            } else {
                displayQuickChatMenu();
            }
        }
    }

    private static void displayWelcome() {
        System.out.println("========================================");
        System.out.println("   Welcome to QuickChat Application");
        System.out.println("========================================\n");
    }

    private static void displayMainMenu() {
        System.out.println("\n=== Main Menu ===");
        System.out.println("1. Register");
        System.out.println("2. Login");
        System.out.println("3. Exit");
        System.out.print("Select an option: ");

        String choice = input.nextLine().trim();

        switch (choice) {
            case "1":
                registerUser();
                break;
            case "2":
                loginUser();
                break;
            case "3":
                System.out.println("Thank you for using QuickChat. Goodbye!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void registerUser() {
        System.out.println("\n=== User Registration ===");

        System.out.print("Enter first name: ");
        String firstName = input.nextLine().trim();

        System.out.print("Enter last name: ");
        String lastName = input.nextLine().trim();

        System.out.print("Enter username (must contain '_' and be max 5 characters): ");
        String username = input.nextLine().trim();

        System.out.print("Enter password (min 8 chars, capital letter, number, special char): ");
        String password = input.nextLine().trim();

        System.out.print("Enter cell phone number (with international code, e.g., +27..): ");
        String cellNumber = input.nextLine().trim();

        Login newUser = new Login(username, password, firstName, lastName, cellNumber);
        String registrationResult = newUser.registerUser();
        System.out.println("\n" + registrationResult);

        if (registrationResult.contains("successfully added")) {
            registeredUsers.add(newUser);
            System.out.println("Registration successful!");
        }
    }

    private static void loginUser() {
        System.out.println("\n=== User Login ===");

        System.out.print("Enter username: ");
        String username = input.nextLine().trim();

        System.out.print("Enter password: ");
        String password = input.nextLine().trim();

        for (Login user : registeredUsers) {
            if (user.loginUser(username, password)) {
                currentUser = user;
                System.out.println(currentUser.returnLoginStatus(true));
                System.out.println("Welcome to QuickChat.");
                return;
            }
        }

        System.out.println("Username or password incorrect, please try again.");
    }

    private static void displayQuickChatMenu() {
        System.out.println("\n=== QuickChat Menu ===");
        System.out.println("1. Send Messages");
        System.out.println("2. Show recently sent messages (Coming Soon)");
        System.out.println("3. View Stored Messages");
        System.out.println("4. Logout");
        System.out.print("Select an option: ");

        String choice = input.nextLine().trim();

        switch (choice) {
            case "1":
                sendMessages();
                break;
            case "2":
                System.out.println("Coming Soon.");
                break;
            case "3":
                viewStoredMessages();
                break;
            case "4":
                logout();
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void sendMessages() {
        System.out.println("\n=== Send Messages ===");

        System.out.print("How many messages do you want to send? ");
        int numMessages = 0;

        try {
            numMessages = Integer.parseInt(input.nextLine().trim());
            if (numMessages <= 0) {
                System.out.println("Please enter a valid number.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
            return;
        }

        for (int i = 0; i < numMessages; i++) {
            System.out.println("\n--- Message " + (i + 1) + " ---");

            System.out.print("Enter message ID: ");
            String messageID = input.nextLine().trim();

            System.out.print("Enter recipient cell number: ");
            String recipient = input.nextLine().trim();

            System.out.print("Enter message (max 250 characters): ");
            String messageText = input.nextLine().trim();

            Message msg = new Message(messageID, recipient, messageText);
            msg.setNumMessagesSent(i + 1);

            if (msg.checkMessageID() && msg.checkRecipientCell() != null && messageText.length() <= 250) {
                msg.sentMessage();
                msg.setMessageHash(msg.createMessageHash());

                System.out.println("\nMessage Options:");
                System.out.println("1. Send Message");
                System.out.println("2. Disregard Message");
                System.out.println("3. Store Message to send later");
                System.out.print("Select option: ");

                String option = input.nextLine().trim();

                switch (option) {
                    case "1":
                        messageStore.addSentMessage(msg);
                        System.out.println("Message successfully sent");
                        break;
                    case "2":
                        messageStore.addDisregardedMessage(msg);
                        System.out.println("Press 0 to delete the message");
                        break;
                    case "3":
                        messageStore.addStoredMessage(msg);
                        System.out.println("Message successfully stored");
                        break;
                    default:
                        System.out.println("Invalid option.");
                }
            } else {
                System.out.println("Message validation failed. Please check message details.");
            }
        }

        if (messageStore.getTotalSentMessages() > 0) {
            System.out.println("\n--- Messages Sent Summary ---");
            for (Message msg : messageStore.getSentMessages()) {
                System.out.println("Message ID: " + msg.getMessageID() + ", Hash: " + msg.getMessageHash() 
                    + ", Recipient: " + msg.getRecipient() + ", Message: " + msg.getMessage());
            }
        }
    }

    private static void viewStoredMessages() {
        if (messageStore.getTotalStoredMessages() == 0) {
            System.out.println("\nNo stored messages available.");
            return;
        }

        System.out.println("\n=== Stored Messages Menu ===");
        System.out.println("1. Display sender and recipient of all stored messages");
        System.out.println("2. Display the longest stored message");
        System.out.println("3. Search for a message ID");
        System.out.println("4. Search messages by recipient");
        System.out.println("5. Delete a message using message hash");
        System.out.println("6. Display full report of all stored messages");
        System.out.println("7. Back to main menu");
        System.out.print("Select an option: ");

        String choice = input.nextLine().trim();

        switch (choice) {
            case "1":
                messageStore.displaySenderAndRecipient();
                break;
            case "2":
                messageStore.displayLongestMessage();
                break;
            case "3":
                System.out.print("Enter message ID to search: ");
                String searchID = input.nextLine().trim();
                messageStore.searchMessageByID(searchID);
                break;
            case "4":
                System.out.print("Enter recipient to search: ");
                String searchRecipient = input.nextLine().trim();
                messageStore.searchMessagesByRecipient(searchRecipient);
                break;
            case "5":
                System.out.print("Enter message hash to delete: ");
                String hashToDelete = input.nextLine().trim();
                messageStore.deleteMessageByHash(hashToDelete);
                break;
            case "6":
                messageStore.displayReport();
                messageStore.saveMessagesToJSON();
                break;
            case "7":
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    private static void logout() {
        System.out.println("Logged out successfully. Goodbye " + currentUser.getFirstName() + "!");
        currentUser = null;
    }
}
