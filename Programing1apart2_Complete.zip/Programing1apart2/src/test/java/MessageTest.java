import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import com.mycompany.programing1apart2.Message;

public class MessageTest {

    private Message message;

    @BeforeEach
    public void setUp() {
        message = new Message("msg_1", "+27838884567", "Hi Mike, can you join us for dinner tonight?");
    }

    @Test
    public void testMessageIDCorrectlyFormatted() {
        assertTrue(message.checkMessageID(), "Message ID should be valid (not more than 10 characters)");
    }

    @Test
    public void testRecipientNumberCorrectlyFormatted() {
        assertNotNull(message.checkRecipientCell(), "Cell phone number should be correctly formatted");
    }

    @Test
    public void testMessageLengthValid() {
        assertTrue(message.getMessage().length() <= 250, "Message should not exceed 250 characters");
    }

    @Test
    public void testMessageLengthInvalid() {
        String longMessage = "a".repeat(251);
        Message invalidMsg = new Message("msg_2", "+27838884567", longMessage);
        String result = invalidMsg.sentMessage();
        assertNotNull(result);
        assertTrue(result.contains("Message exceeds 250 characters"), "Should return error for message exceeding 250 characters");
    }

    @Test
    public void testMessageHashGeneration() {
        message.setNumMessagesSent(1);
        String hash = message.createMessageHash();
        assertNotNull(hash, "Message hash should be generated");
        assertTrue(hash.contains(":"), "Hash should contain colon separator");
    }

    @Test
    public void testSentMessageSuccess() {
        message.setNumMessagesSent(1);
        String result = message.sentMessage();
        assertNotNull(result);
        assertEquals("Message sent", result, "Should return 'Message sent' on success");
    }

    @Test
    public void testPrintMessages() {
        message.setMessageHash("00:1:HITHANKS");
        String printed = message.printMessages();
        assertNotNull(printed);
        assertTrue(printed.contains("Message ID:"), "Print format should include Message ID");
        assertTrue(printed.contains("Hash:"), "Print format should include Hash");
        assertTrue(printed.contains("Recipient:"), "Print format should include Recipient");
    }

    @Test
    public void testReturnTotalMessages() {
        message.setNumMessagesSent(5);
        assertEquals(5, message.returnTotalMessages(), "Should return correct total messages sent");
    }

    @Test
    public void testGetters() {
        assertEquals("msg_1", message.getMessageID(), "Should return correct message ID");
        assertEquals("+27838884567", message.getRecipient(), "Should return correct recipient");
        assertTrue(message.getMessage().contains("dinner"), "Should return correct message text");
    }

    @Test
    public void testMessageFlag() {
        assertEquals("Sent", message.getMessageFlag(), "Default flag should be 'Sent'");
        message.setMessageFlag("Stored");
        assertEquals("Stored", message.getMessageFlag(), "Should update message flag");
    }
}
