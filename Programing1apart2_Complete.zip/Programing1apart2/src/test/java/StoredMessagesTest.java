import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import com.mycompany.programing1apart2.StoredMessages;
import com.mycompany.programing1apart2.Message;
import java.util.List;

public class StoredMessagesTest {

    private StoredMessages messageStore;
    private Message testMessage1;
    private Message testMessage2;
    private Message testMessage3;

    @BeforeEach
    public void setUp() {
        messageStore = new StoredMessages();

        testMessage1 = new Message("msg_1", "+27834557896", "Did you get the cake?");
        testMessage1.setMessageHash("00:0:HIITHANKS");
        testMessage1.setNumMessagesSent(1);

        testMessage2 = new Message("msg_2", "+27838884567", "Where are you? You are late! I have asked you to be on time.");
        testMessage2.setMessageHash("00:1:WHEREOK");
        testMessage2.setNumMessagesSent(1);

        testMessage3 = new Message("msg_3", "+27834484567", "Yohoooo, I am at your gate.");
        testMessage3.setMessageHash("04:1:YOHOOGATE");
        testMessage3.setNumMessagesSent(1);
    }

    @Test
    public void testAddSentMessage() {
        messageStore.addSentMessage(testMessage1);
        assertEquals(1, messageStore.getTotalSentMessages(), "Should have 1 sent message");
        assertTrue(messageStore.getSentMessages().contains(testMessage1), "Sent messages list should contain added message");
    }

    @Test
    public void testAddStoredMessage() {
        messageStore.addStoredMessage(testMessage2);
        assertEquals(1, messageStore.getTotalStoredMessages(), "Should have 1 stored message");
        assertTrue(messageStore.getStoredMessages().contains(testMessage2), "Stored messages list should contain added message");
    }

    @Test
    public void testAddDisregardedMessage() {
        messageStore.addDisregardedMessage(testMessage3);
        assertEquals(1, messageStore.getTotalDisregardedMessages(), "Should have 1 disregarded message");
        assertTrue(messageStore.getDisregardedMessages().contains(testMessage3), "Disregarded messages list should contain added message");
    }

    @Test
    public void testDisplayLongestMessage() {
        messageStore.addStoredMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);

        String longest = messageStore.displayLongestMessage();
        assertEquals("Where are you? You are late! I have asked you to be on time.", longest, "Should return the longest message");
    }

    @Test
    public void testSearchMessageByID() {
        messageStore.addStoredMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);

        Message found = messageStore.searchMessageByID("msg_2");
        assertNotNull(found, "Should find message by ID");
        assertEquals(testMessage2.getMessage(), found.getMessage(), "Should return correct message");
    }

    @Test
    public void testSearchMessageByIDNotFound() {
        messageStore.addStoredMessage(testMessage1);
        Message found = messageStore.searchMessageByID("msg_99");
        assertNull(found, "Should return null when message ID not found");
    }

    @Test
    public void testSearchMessagesByRecipient() {
        messageStore.addStoredMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);
        messageStore.addStoredMessage(testMessage3);

        List<Message> results = messageStore.searchMessagesByRecipient("+27838884567");
        assertEquals(1, results.size(), "Should find 1 message for this recipient");
        assertEquals(testMessage2, results.get(0), "Should return correct message");
    }

    @Test
    public void testDeleteMessageByHash() {
        messageStore.addStoredMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);

        boolean deleted = messageStore.deleteMessageByHash("00:0:HIITHANKS");
        assertTrue(deleted, "Should successfully delete message");
        assertEquals(1, messageStore.getTotalStoredMessages(), "Should have 1 message remaining after deletion");
    }

    @Test
    public void testDeleteMessageByHashNotFound() {
        messageStore.addStoredMessage(testMessage1);

        boolean deleted = messageStore.deleteMessageByHash("NONEXISTENT");
        assertFalse(deleted, "Should return false when hash not found");
        assertEquals(1, messageStore.getTotalStoredMessages(), "Number of messages should remain unchanged");
    }

    @Test
    public void testMessageHashArrayPopulation() {
        messageStore.addSentMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);

        List<String> hashes = messageStore.getMessageHashArray();
        assertEquals(2, hashes.size(), "Hash array should contain 2 hashes");
        assertTrue(hashes.contains("00:0:HIITHANKS"), "Should contain first message hash");
        assertTrue(hashes.contains("00:1:WHEREOK"), "Should contain second message hash");
    }

    @Test
    public void testMessageIDArrayPopulation() {
        messageStore.addSentMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);

        List<String> ids = messageStore.getMessageIDArray();
        assertEquals(2, ids.size(), "ID array should contain 2 IDs");
        assertTrue(ids.contains("msg_1"), "Should contain first message ID");
        assertTrue(ids.contains("msg_2"), "Should contain second message ID");
    }

    @Test
    public void testGetTotalStoredMessages() {
        messageStore.addStoredMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);
        messageStore.addStoredMessage(testMessage3);

        assertEquals(3, messageStore.getTotalStoredMessages(), "Should return correct total of stored messages");
    }

    @Test
    public void testGetters() {
        messageStore.addSentMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);
        messageStore.addDisregardedMessage(testMessage3);

        assertNotNull(messageStore.getSentMessages(), "Sent messages list should not be null");
        assertNotNull(messageStore.getStoredMessages(), "Stored messages list should not be null");
        assertNotNull(messageStore.getDisregardedMessages(), "Disregarded messages list should not be null");
    }

    @Test
    public void testSaveAndLoadMessagesFromJSON() {
        messageStore.addStoredMessage(testMessage1);
        messageStore.addStoredMessage(testMessage2);

        messageStore.saveMessagesToJSON();

        StoredMessages newStore = new StoredMessages();
        newStore.loadMessagesFromJSON();

        assertEquals(2, newStore.getTotalStoredMessages(), "Loaded store should have 2 messages");
        assertNotNull(newStore.searchMessageByID("msg_1"), "Should find loaded message 1");
        assertNotNull(newStore.searchMessageByID("msg_2"), "Should find loaded message 2");
    }

    @Test
    public void testLoadMessagesPreservesData() {
        messageStore.addStoredMessage(testMessage1);
        messageStore.saveMessagesToJSON();

        StoredMessages loadedStore = new StoredMessages();
        loadedStore.loadMessagesFromJSON();

        Message loaded = loadedStore.searchMessageByID("msg_1");
        assertNotNull(loaded, "Message should be loaded");
        assertEquals(testMessage1.getMessage(), loaded.getMessage(), "Message content should match");
        assertEquals(testMessage1.getRecipient(), loaded.getRecipient(), "Recipient should match");
        assertEquals(testMessage1.getMessageHash(), loaded.getMessageHash(), "Hash should match");
    }
}
